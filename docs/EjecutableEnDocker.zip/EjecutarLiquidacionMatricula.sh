﻿#!/bin/bash
# docker run -d -p 3306:3306 --name mysql-ud futbolsalas15/mysql-espingsw-bd &
cd mysql
docker build --tag=mysql-app .
docker run -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=abc.123 --name mysql-ud mysql-app
cd ../wildfly
docker build --tag=app-ud .
docker run -d -p 8081:8080 --name app-ud --link mysql-ud:docker.dev app-ud